#!/usr/bin/env python3
"""
Gatekeeper Web Interface
A Flask-based web interface for monitoring and managing the Gatekeeper DDoS protection system.
"""

from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from flask_socketio import SocketIO, emit
import json
import time
import subprocess
import psutil
import os
import threading
from datetime import datetime, timedelta
import sqlite3
from collections import defaultdict, deque
import logging
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = 'gatekeeper-secret-key-2024'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="gevent")

# Global variables for storing metrics
metrics_history = {
    'packets_processed': deque(maxlen=1000),
    'packets_dropped': deque(maxlen=1000),
    'attack_attempts': deque(maxlen=1000),
    'cpu_usage': deque(maxlen=1000),
    'memory_usage': deque(maxlen=1000),
    'network_throughput': deque(maxlen=1000),
    'active_flows': deque(maxlen=1000),
    'blocked_ips': deque(maxlen=1000)
}

# Attack tracking
attack_history = deque(maxlen=1000)
active_attacks = {}

# Discord webhook configuration
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1401937015230169149/WEJCUtxhytdk1N49106OA3YOIv3Y6rlAkRaT8N0Aw2s31turq_jb8BqbeXFeneU-fqHx"

# Configuration
GATEKEEPER_CONFIG = {
    'log_file': '/var/log/gatekeeper/gatekeeper.log',
    'config_dir': '/etc/gatekeeper',
    'status_file': '/var/run/gatekeeper.status',
    'metrics_interval': 5  # seconds
}

# Attack types
ATTACK_TYPES = {
    'SYN_FLOOD': 'SYN Flood',
    'UDP_FLOOD': 'UDP Flood',
    'ICMP_FLOOD': 'ICMP Flood',
    'HTTP_FLOOD': 'HTTP Flood',
    'DNS_AMPLIFICATION': 'DNS Amplification',
    'NTP_AMPLIFICATION': 'NTP Amplification',
    'SNMP_AMPLIFICATION': 'SNMP Amplification',
    'SSDP_AMPLIFICATION': 'SSDP Amplification',
    'CHARGEN_AMPLIFICATION': 'CHARGEN Amplification',
    'SMURF': 'Smurf Attack',
    'FRAGGLE': 'Fraggle Attack',
    'LAND': 'Land Attack',
    'TEARDROP': 'Teardrop Attack',
    'PING_OF_DEATH': 'Ping of Death',
    'SLOWLORIS': 'Slowloris Attack',
    'RUDY': 'RUDY Attack',
    'CUSTOM': 'Custom Attack'
}

def send_discord_alert(attack_data):
    """Send attack alert to Discord webhook"""
    try:
        embed = {
            "title": f"🚨 DDoS Attack Detected - {attack_data['type']}",
            "color": 0xFF0000,
            "fields": [
                {
                    "name": "Attack Type",
                    "value": attack_data['type'],
                    "inline": True
                },
                {
                    "name": "Start Time",
                    "value": attack_data['start_time'],
                    "inline": True
                },
                {
                    "name": "End Time",
                    "value": attack_data.get('end_time', 'Ongoing'),
                    "inline": True
                },
                {
                    "name": "Attack Size",
                    "value": f"{attack_data['size_mbps']:.2f} Mbps",
                    "inline": True
                },
                {
                    "name": "Status",
                    "value": "✅ Blocked" if attack_data.get('blocked', False) else "❌ Not Blocked",
                    "inline": True
                },
                {
                    "name": "Attacker IPs",
                    "value": ", ".join(attack_data.get('attacker_ips', [])),
                    "inline": False
                }
            ],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        payload = {
            "embeds": [embed]
        }
        
        response = requests.post(DISCORD_WEBHOOK_URL, json=payload)
        if response.status_code == 204:
            logging.info("Discord alert sent successfully")
        else:
            logging.error(f"Failed to send Discord alert: {response.status_code}")
            
    except Exception as e:
        logging.error(f"Error sending Discord alert: {e}")

class GatekeeperMonitor:
    def __init__(self):
        self.is_running = False
        self.monitor_thread = None
        self.last_attack_check = time.time()
        
    def start_monitoring(self):
        if not self.is_running:
            self.is_running = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
    
    def stop_monitoring(self):
        self.is_running = False
    
    def _monitor_loop(self):
        while self.is_running:
            try:
                self._collect_metrics()
                self._check_for_attacks()
                socketio.emit('metrics_update', self._get_current_metrics())
                time.sleep(GATEKEEPER_CONFIG['metrics_interval'])
            except Exception as e:
                logging.error(f"Error in monitoring loop: {e}")
    
    def _check_for_attacks(self):
        """Check for new attacks and send alerts"""
        current_time = time.time()
        
        # Simulate attack detection (replace with actual detection logic)
        if current_time - self.last_attack_check > 30:  # Check every 30 seconds
            self.last_attack_check = current_time
            
            # Simulate random attack detection
            if int(current_time) % 300 == 0:  # Every 5 minutes
                attack_type = list(ATTACK_TYPES.keys())[int(current_time) % len(ATTACK_TYPES)]
                attacker_ips = [f"192.168.{int(current_time) % 255}.{int(current_time) % 255}"]
                attack_size = float(current_time % 1000) + 100.0
                
                attack_data = {
                    'id': f"attack_{int(current_time)}",
                    'type': ATTACK_TYPES[attack_type],
                    'attack_type': attack_type,
                    'start_time': datetime.fromtimestamp(current_time).strftime('%Y-%m-%d %H:%M:%S'),
                    'size_mbps': attack_size,
                    'attacker_ips': attacker_ips,
                    'attacked_ports': [80, 443],
                    'blocked': True,
                    'duration_seconds': 60
                }
                
                # Add to attack history
                attack_history.append(attack_data)
                active_attacks[attack_data['id']] = attack_data
                
                # Send Discord alert
                send_discord_alert(attack_data)
                
                # Emit attack notification to web interface
                socketio.emit('attack_detected', attack_data)
                
                # Remove from active attacks after duration
                threading.Timer(attack_data['duration_seconds'], 
                              lambda: self._end_attack(attack_data['id'])).start()
    
    def _end_attack(self, attack_id):
        """End an attack and update status"""
        if attack_id in active_attacks:
            attack_data = active_attacks[attack_id]
            attack_data['end_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            attack_data['duration_seconds'] = int(time.time() - datetime.strptime(attack_data['start_time'], '%Y-%m-%d %H:%M:%S').timestamp())
            
            # Send final Discord alert
            send_discord_alert(attack_data)
            
            # Remove from active attacks
            del active_attacks[attack_id]
            
            # Emit attack ended notification
            socketio.emit('attack_ended', attack_data)
    
    def _collect_metrics(self):
        """Collect real-time metrics from Gatekeeper"""
        timestamp = time.time()
        
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        
        # Simulate Gatekeeper-specific metrics (replace with actual data collection)
        packets_processed = self._get_packets_processed()
        packets_dropped = self._get_packets_dropped()
        attack_attempts = self._get_attack_attempts()
        network_throughput = self._get_network_throughput()
        active_flows = self._get_active_flows()
        blocked_ips = self._get_blocked_ips()
        
        # Store metrics with smoother data
        self._store_smooth_metric('cpu_usage', timestamp, cpu_percent)
        self._store_smooth_metric('memory_usage', timestamp, memory.percent)
        self._store_smooth_metric('packets_processed', timestamp, packets_processed)
        self._store_smooth_metric('packets_dropped', timestamp, packets_dropped)
        self._store_smooth_metric('attack_attempts', timestamp, attack_attempts)
        self._store_smooth_metric('network_throughput', timestamp, network_throughput)
        self._store_smooth_metric('active_flows', timestamp, active_flows)
        self._store_smooth_metric('blocked_ips', timestamp, blocked_ips)
    
    def _store_smooth_metric(self, metric_name, timestamp, value):
        """Store metric with smoothing for better graph appearance"""
        if len(metrics_history[metric_name]) > 0:
            # Apply exponential smoothing for smoother graphs
            last_value = metrics_history[metric_name][-1]['value']
            alpha = 0.3  # Smoothing factor
            smoothed_value = alpha * value + (1 - alpha) * last_value
        else:
            smoothed_value = value
        
        metrics_history[metric_name].append({
            'timestamp': timestamp,
            'value': smoothed_value
        })
    
    def _get_packets_processed(self):
        """Get packets processed count from Gatekeeper logs"""
        try:
            # This would parse actual Gatekeeper logs
            # For now, return simulated data
            return int(time.time() % 10000) + 1000
        except:
            return 0
    
    def _get_packets_dropped(self):
        """Get packets dropped count"""
        try:
            return int(time.time() % 100) + 10
        except:
            return 0
    
    def _get_attack_attempts(self):
        """Get attack attempts count"""
        try:
            return int(time.time() % 50) + 5
        except:
            return 0
    
    def _get_network_throughput(self):
        """Get network throughput in Mbps"""
        try:
            return float(time.time() % 1000) + 100.0
        except:
            return 0.0
    
    def _get_active_flows(self):
        """Get active flows count"""
        try:
            return int(time.time() % 5000) + 500
        except:
            return 0
    
    def _get_blocked_ips(self):
        """Get blocked IPs count"""
        try:
            return int(time.time() % 100) + 20
        except:
            return 0
    
    def _get_current_metrics(self):
        """Get current metrics for real-time updates"""
        return {
            'cpu_usage': metrics_history['cpu_usage'][-1]['value'] if metrics_history['cpu_usage'] else 0,
            'memory_usage': metrics_history['memory_usage'][-1]['value'] if metrics_history['memory_usage'] else 0,
            'packets_processed': metrics_history['packets_processed'][-1]['value'] if metrics_history['packets_processed'] else 0,
            'packets_dropped': metrics_history['packets_dropped'][-1]['value'] if metrics_history['packets_dropped'] else 0,
            'attack_attempts': metrics_history['attack_attempts'][-1]['value'] if metrics_history['attack_attempts'] else 0,
            'network_throughput': metrics_history['network_throughput'][-1]['value'] if metrics_history['network_throughput'] else 0,
            'active_flows': metrics_history['active_flows'][-1]['value'] if metrics_history['active_flows'] else 0,
            'blocked_ips': metrics_history['blocked_ips'][-1]['value'] if metrics_history['blocked_ips'] else 0,
            'timestamp': time.time()
        }

# Initialize monitor
monitor = GatekeeperMonitor()

@app.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/metrics')
def metrics():
    """Metrics page with detailed graphs"""
    return render_template('metrics.html')

@app.route('/configuration')
def configuration():
    """Configuration management page"""
    return render_template('configuration.html')

@app.route('/logs')
def logs():
    """Log viewer page"""
    return render_template('logs.html')

@app.route('/attacks')
def attacks():
    """Attack history page"""
    return render_template('attacks.html')

@app.route('/api/metrics')
def api_metrics():
    """API endpoint for metrics data"""
    return jsonify({
        'packets_processed': list(metrics_history['packets_processed']),
        'packets_dropped': list(metrics_history['packets_dropped']),
        'attack_attempts': list(metrics_history['attack_attempts']),
        'cpu_usage': list(metrics_history['cpu_usage']),
        'memory_usage': list(metrics_history['memory_usage']),
        'network_throughput': list(metrics_history['network_throughput']),
        'active_flows': list(metrics_history['active_flows']),
        'blocked_ips': list(metrics_history['blocked_ips'])
    })

@app.route('/api/attacks')
def api_attacks():
    """API endpoint for attack history"""
    return jsonify({
        'active_attacks': list(active_attacks.values()),
        'attack_history': list(attack_history),
        'attack_types': ATTACK_TYPES
    })

@app.route('/api/attack/<attack_id>')
def api_attack_details(attack_id):
    """API endpoint for specific attack details"""
    # Find attack in history
    for attack in attack_history:
        if attack['id'] == attack_id:
            return jsonify(attack)
    
    # Check active attacks
    if attack_id in active_attacks:
        return jsonify(active_attacks[attack_id])
    
    return jsonify({'error': 'Attack not found'}), 404

@app.route('/api/status')
def api_status():
    """API endpoint for system status"""
    try:
        # Check if Gatekeeper process is running
        gatekeeper_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if 'gatekeeper' in proc.info['name'].lower():
                gatekeeper_running = True
                break
        
        return jsonify({
            'gatekeeper_running': gatekeeper_running,
            'system_uptime': time.time() - psutil.boot_time(),
            'cpu_count': psutil.cpu_count(),
            'memory_total': psutil.virtual_memory().total,
            'disk_usage': psutil.disk_usage('/').percent,
            'active_attacks_count': len(active_attacks)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/start_gatekeeper', methods=['POST'])
def api_start_gatekeeper():
    """API endpoint to start Gatekeeper"""
    try:
        # This would actually start Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'start', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper started'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/stop_gatekeeper', methods=['POST'])
def api_stop_gatekeeper():
    """API endpoint to stop Gatekeeper"""
    try:
        # This would actually stop Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'stop', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper stopped'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/restart_gatekeeper', methods=['POST'])
def api_restart_gatekeeper():
    """API endpoint to restart Gatekeeper"""
    try:
        # This would actually restart Gatekeeper
        # subprocess.run(['sudo', 'systemctl', 'restart', 'gatekeeper'])
        return jsonify({'status': 'success', 'message': 'Gatekeeper restarted'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/block_ip', methods=['POST'])
def api_block_ip():
    """API endpoint to block an IP address"""
    try:
        data = request.get_json()
        ip_address = data.get('ip_address')
        duration = data.get('duration', 3600)  # Default 1 hour
        
        if not ip_address:
            return jsonify({'status': 'error', 'message': 'IP address required'}), 400
        
        # This would actually block the IP in Gatekeeper
        # Implementation would depend on Gatekeeper's API
        
        return jsonify({
            'status': 'success', 
            'message': f'IP {ip_address} blocked for {duration} seconds'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/unblock_ip', methods=['POST'])
def api_unblock_ip():
    """API endpoint to unblock an IP address"""
    try:
        data = request.get_json()
        ip_address = data.get('ip_address')
        
        if not ip_address:
            return jsonify({'status': 'error', 'message': 'IP address required'}), 400
        
        # This would actually unblock the IP in Gatekeeper
        
        return jsonify({
            'status': 'success', 
            'message': f'IP {ip_address} unblocked'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/get_logs')
def api_get_logs():
    """API endpoint to get recent logs"""
    try:
        lines = request.args.get('lines', 100, type=int)
        
        # This would read actual Gatekeeper logs
        # For now, return simulated logs
        logs = []
        for i in range(lines):
            logs.append({
                'timestamp': datetime.now() - timedelta(seconds=i*10),
                'level': 'INFO' if i % 3 == 0 else 'WARNING' if i % 5 == 0 else 'ERROR',
                'message': f'Simulated log message {i}'
            })
        
        return jsonify({'logs': logs})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    print('Client connected')
    emit('connected', {'data': 'Connected to Gatekeeper Web Interface'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    print('Client disconnected')

if __name__ == '__main__':
    # Start monitoring
    monitor.start_monitoring()
    
    # Run the Flask app
    socketio.run(app, host='0.0.0.0', port=5000, debug=True) 