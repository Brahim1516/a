/*
 * Enhanced Gatekeeper - Advanced DDoS Protection System
 * Copyright (C) 2024 Enhanced Gatekeeper Project
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef GATEKEEPER_ENHANCED_H
#define GATEKEEPER_ENHANCED_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>

/* Enhanced DDoS Protection Features */
#define ENHANCED_MAX_ATTACK_TYPES 16
#define ENHANCED_MAX_GEO_REGIONS 256
#define ENHANCED_MAX_BEHAVIOR_PATTERNS 64
#define ENHANCED_MAX_ML_FEATURES 32

/* Attack Detection Thresholds */
#define ENHANCED_SYN_FLOOD_THRESHOLD 1000
#define ENHANCED_UDP_FLOOD_THRESHOLD 5000
#define ENHANCED_ICMP_FLOOD_THRESHOLD 1000
#define ENHANCED_HTTP_FLOOD_THRESHOLD 2000
#define ENHANCED_DNS_AMPLIFICATION_THRESHOLD 1000
#define ENHANCED_NTP_AMPLIFICATION_THRESHOLD 500

/* Rate Limiting */
#define ENHANCED_DEFAULT_RATE_LIMIT 1000
#define ENHANCED_BURST_LIMIT 100
#define ENHANCED_CONNECTION_LIMIT 1000

/* Machine Learning Features */
#define ENHANCED_ML_WINDOW_SIZE 1000
#define ENHANCED_ML_UPDATE_INTERVAL 60
#define ENHANCED_ML_CONFIDENCE_THRESHOLD 0.8

/* Behavioral Analysis */
#define ENHANCED_BEHAVIOR_WINDOW 300
#define ENHANCED_BEHAVIOR_SAMPLES 1000
#define ENHANCED_ANOMALY_THRESHOLD 2.5

/* Geographic Protection */
#define ENHANCED_GEO_DB_PATH "/usr/share/GeoIP/GeoIP.dat"
#define ENHANCED_GEO_CACHE_SIZE 10000

/* Protocol Analysis */
typedef enum {
    ENHANCED_PROTO_HTTP = 0,
    ENHANCED_PROTO_HTTPS,
    ENHANCED_PROTO_DNS,
    ENHANCED_PROTO_SMTP,
    ENHANCED_PROTO_FTP,
    ENHANCED_PROTO_SSH,
    ENHANCED_PROTO_TELNET,
    ENHANCED_PROTO_RDP,
    ENHANCED_PROTO_VNC,
    ENHANCED_PROTO_CUSTOM
} enhanced_protocol_t;

/* Attack Types */
typedef enum {
    ENHANCED_ATTACK_SYN_FLOOD = 0,
    ENHANCED_ATTACK_UDP_FLOOD,
    ENHANCED_ATTACK_ICMP_FLOOD,
    ENHANCED_ATTACK_HTTP_FLOOD,
    ENHANCED_ATTACK_DNS_AMPLIFICATION,
    ENHANCED_ATTACK_NTP_AMPLIFICATION,
    ENHANCED_ATTACK_SNMP_AMPLIFICATION,
    ENHANCED_ATTACK_SSDP_AMPLIFICATION,
    ENHANCED_ATTACK_CHARGEN_AMPLIFICATION,
    ENHANCED_ATTACK_SMURF,
    ENHANCED_ATTACK_FRAGGLE,
    ENHANCED_ATTACK_LAND,
    ENHANCED_ATTACK_TEARDROP,
    ENHANCED_ATTACK_PING_OF_DEATH,
    ENHANCED_ATTACK_SLOWLORIS,
    ENHANCED_ATTACK_RUDY,
    ENHANCED_ATTACK_CUSTOM
} enhanced_attack_type_t;

/* Behavioral Patterns */
typedef enum {
    ENHANCED_BEHAVIOR_NORMAL = 0,
    ENHANCED_BEHAVIOR_AGGRESSIVE,
    ENHANCED_BEHAVIOR_SCANNING,
    ENHANCED_BEHAVIOR_BOTNET,
    ENHANCED_BEHAVIOR_MALWARE,
    ENHANCED_BEHAVIOR_ANOMALOUS
} enhanced_behavior_type_t;

/* Machine Learning Models */
typedef enum {
    ENHANCED_ML_MODEL_RANDOM_FOREST = 0,
    ENHANCED_ML_MODEL_SVM,
    ENHANCED_ML_MODEL_NEURAL_NETWORK,
    ENHANCED_ML_MODEL_ISOLATION_FOREST,
    ENHANCED_ML_MODEL_LOF,
    ENHANCED_ML_MODEL_CUSTOM
} enhanced_ml_model_t;

/* Enhanced Flow State */
typedef struct enhanced_flow_state {
    /* Basic Flow Information */
    uint32_t src_ip;
    uint32_t dst_ip;
    uint16_t src_port;
    uint16_t dst_port;
    uint8_t protocol;
    
    /* Rate Limiting */
    uint64_t packets_per_sec;
    uint64_t bytes_per_sec;
    uint64_t connections_per_sec;
    uint64_t last_packet_time;
    uint64_t last_connection_time;
    
    /* Attack Detection */
    uint32_t attack_counters[ENHANCED_MAX_ATTACK_TYPES];
    uint64_t attack_timestamps[ENHANCED_MAX_ATTACK_TYPES];
    bool attack_detected;
    enhanced_attack_type_t detected_attack;
    
    /* Behavioral Analysis */
    enhanced_behavior_type_t behavior_type;
    float behavior_score;
    uint32_t behavior_samples;
    uint64_t behavior_window_start;
    
    /* Machine Learning Features */
    float ml_features[ENHANCED_ML_FEATURES];
    float ml_score;
    bool ml_anomaly_detected;
    enhanced_ml_model_t ml_model;
    
    /* Geographic Information */
    uint32_t geo_country_code;
    uint32_t geo_region_code;
    bool geo_blocked;
    
    /* Protocol Analysis */
    enhanced_protocol_t protocol_type;
    uint32_t protocol_specific_flags;
    
    /* Custom Rules */
    uint32_t custom_rule_id;
    bool custom_rule_matched;
    
    /* Statistics */
    uint64_t total_packets;
    uint64_t total_bytes;
    uint64_t dropped_packets;
    uint64_t dropped_bytes;
    
    /* Timestamps */
    uint64_t flow_start_time;
    uint64_t last_activity_time;
    uint64_t last_update_time;
} enhanced_flow_state_t;

/* Enhanced Configuration */
typedef struct enhanced_config {
    /* Attack Detection */
    bool enable_syn_flood_detection;
    bool enable_udp_flood_detection;
    bool enable_icmp_flood_detection;
    bool enable_http_flood_detection;
    bool enable_dns_amplification_detection;
    bool enable_ntp_amplification_detection;
    
    /* Rate Limiting */
    uint32_t default_rate_limit;
    uint32_t burst_limit;
    uint32_t connection_limit;
    
    /* Machine Learning */
    bool enable_ml_detection;
    enhanced_ml_model_t ml_model;
    float ml_confidence_threshold;
    uint32_t ml_window_size;
    uint32_t ml_update_interval;
    
    /* Behavioral Analysis */
    bool enable_behavioral_analysis;
    uint32_t behavior_window_size;
    uint32_t behavior_sample_size;
    float anomaly_threshold;
    
    /* Geographic Protection */
    bool enable_geo_protection;
    char geo_db_path[256];
    uint32_t geo_cache_size;
    
    /* Protocol Analysis */
    bool enable_protocol_analysis;
    bool enable_custom_protocols;
    
    /* Logging */
    bool enable_enhanced_logging;
    uint32_t log_level;
    char log_file_path[256];
    
    /* Performance */
    uint32_t max_flows;
    uint32_t flow_timeout;
    uint32_t cleanup_interval;
    
    /* Custom Rules */
    bool enable_custom_rules;
    uint32_t max_custom_rules;
    char custom_rules_file[256];
} enhanced_config_t;

/* Enhanced Statistics */
typedef struct enhanced_stats {
    /* Attack Statistics */
    uint64_t attack_detections[ENHANCED_MAX_ATTACK_TYPES];
    uint64_t attack_blocks[ENHANCED_MAX_ATTACK_TYPES];
    
    /* Rate Limiting Statistics */
    uint64_t rate_limit_violations;
    uint64_t burst_limit_violations;
    uint64_t connection_limit_violations;
    
    /* Machine Learning Statistics */
    uint64_t ml_predictions;
    uint64_t ml_anomalies_detected;
    float ml_accuracy;
    
    /* Behavioral Statistics */
    uint64_t behavioral_anomalies;
    uint64_t behavior_patterns_detected;
    
    /* Geographic Statistics */
    uint64_t geo_blocks;
    uint64_t geo_allows;
    
    /* Protocol Statistics */
    uint64_t protocol_violations;
    uint64_t custom_protocol_detections;
    
    /* General Statistics */
    uint64_t total_flows;
    uint64_t active_flows;
    uint64_t total_packets;
    uint64_t total_bytes;
    uint64_t dropped_packets;
    uint64_t dropped_bytes;
    
    /* Performance Statistics */
    uint64_t processing_time_ns;
    uint64_t memory_usage_bytes;
    uint64_t cpu_usage_percent;
} enhanced_stats_t;

/* Function Declarations */

/* Configuration */
int enhanced_init_config(enhanced_config_t *config);
int enhanced_load_config(const char *config_file);
int enhanced_save_config(const char *config_file);

/* Flow Management */
enhanced_flow_state_t *enhanced_create_flow_state(uint32_t src_ip, uint32_t dst_ip, 
                                                 uint16_t src_port, uint16_t dst_port, 
                                                 uint8_t protocol);
void enhanced_destroy_flow_state(enhanced_flow_state_t *flow);
int enhanced_update_flow_state(enhanced_flow_state_t *flow, uint32_t packet_size);

/* Attack Detection */
bool enhanced_detect_syn_flood(enhanced_flow_state_t *flow);
bool enhanced_detect_udp_flood(enhanced_flow_state_t *flow);
bool enhanced_detect_icmp_flood(enhanced_flow_state_t *flow);
bool enhanced_detect_http_flood(enhanced_flow_state_t *flow);
bool enhanced_detect_dns_amplification(enhanced_flow_state_t *flow);
bool enhanced_detect_ntp_amplification(enhanced_flow_state_t *flow);
enhanced_attack_type_t enhanced_detect_attack(enhanced_flow_state_t *flow);

/* Rate Limiting */
bool enhanced_check_rate_limit(enhanced_flow_state_t *flow, uint32_t packet_size);
bool enhanced_check_burst_limit(enhanced_flow_state_t *flow);
bool enhanced_check_connection_limit(enhanced_flow_state_t *flow);

/* Machine Learning */
int enhanced_init_ml_model(enhanced_ml_model_t model);
float enhanced_predict_anomaly(enhanced_flow_state_t *flow);
int enhanced_update_ml_model(enhanced_flow_state_t *flow, bool is_attack);
int enhanced_train_ml_model(void);

/* Behavioral Analysis */
enhanced_behavior_type_t enhanced_analyze_behavior(enhanced_flow_state_t *flow);
float enhanced_calculate_behavior_score(enhanced_flow_state_t *flow);
bool enhanced_detect_anomaly(enhanced_flow_state_t *flow);

/* Geographic Protection */
int enhanced_init_geo_protection(const char *geo_db_path);
bool enhanced_check_geo_access(enhanced_flow_state_t *flow);
int enhanced_block_geo_region(uint32_t country_code, uint32_t region_code);
int enhanced_allow_geo_region(uint32_t country_code, uint32_t region_code);

/* Protocol Analysis */
enhanced_protocol_t enhanced_analyze_protocol(enhanced_flow_state_t *flow);
bool enhanced_check_protocol_violation(enhanced_flow_state_t *flow);
int enhanced_add_custom_protocol(const char *protocol_name, uint16_t port);

/* Custom Rules */
int enhanced_add_custom_rule(const char *rule_definition);
int enhanced_remove_custom_rule(uint32_t rule_id);
bool enhanced_check_custom_rules(enhanced_flow_state_t *flow);

/* Statistics */
enhanced_stats_t *enhanced_get_stats(void);
int enhanced_reset_stats(void);
int enhanced_export_stats(const char *filename);

/* Logging */
int enhanced_log_attack(enhanced_flow_state_t *flow, enhanced_attack_type_t attack);
int enhanced_log_anomaly(enhanced_flow_state_t *flow, float score);
int enhanced_log_geo_block(enhanced_flow_state_t *flow);

/* Utility Functions */
uint32_t enhanced_ip_to_uint32(const char *ip_str);
char *enhanced_uint32_to_ip(uint32_t ip);
uint64_t enhanced_get_timestamp(void);
float enhanced_calculate_entropy(const uint8_t *data, uint32_t length);

/* Performance Monitoring */
uint64_t enhanced_get_processing_time(void);
uint64_t enhanced_get_memory_usage(void);
float enhanced_get_cpu_usage(void);

#endif /* GATEKEEPER_ENHANCED_H */ 