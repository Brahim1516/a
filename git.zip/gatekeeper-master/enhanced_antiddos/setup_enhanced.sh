#!/bin/bash

# Enhanced Gatekeeper Anti-DDoS Setup Script
# Copyright (C) 2024 Enhanced Gatekeeper Project

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
ENHANCED_VERSION="2.0.0"
INSTALL_DIR="/opt/gatekeeper-enhanced"
CONFIG_DIR="/etc/gatekeeper-enhanced"
LOG_DIR="/var/log/gatekeeper-enhanced"
WEB_INTERFACE_DIR="/opt/gatekeeper-enhanced/web-interface"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root"
        exit 1
    fi
}

# Function to check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check OS
    if [[ ! -f /etc/os-release ]]; then
        print_error "Unsupported operating system"
        exit 1
    fi
    
    # Check kernel version
    KERNEL_VERSION=$(uname -r | cut -d. -f1,2)
    if [[ $(echo "$KERNEL_VERSION >= 4.18" | bc -l) -eq 0 ]]; then
        print_error "Kernel version 4.18 or higher is required"
        exit 1
    fi
    
    # Check available memory
    MEMORY_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    MEMORY_GB=$((MEMORY_KB / 1024 / 1024))
    if [[ $MEMORY_GB -lt 4 ]]; then
        print_warning "At least 4GB RAM is recommended"
    fi
    
    # Check CPU cores
    CPU_CORES=$(nproc)
    if [[ $CPU_CORES -lt 2 ]]; then
        print_warning "At least 2 CPU cores are recommended"
    fi
    
    print_success "System requirements check completed"
}

# Function to install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    
    # Update package list
    apt-get update
    
    # Install system dependencies
    apt-get install -y \
        build-essential \
        cmake \
        git \
        libpcap-dev \
        libssl-dev \
        libjson-c-dev \
        libcurl4-openssl-dev \
        python3 \
        python3-pip \
        python3-dev \
        libpython3-dev \
        nodejs \
        npm \
        nginx \
        redis-server \
        postgresql \
        postgresql-contrib \
        geoip-database \
        geoip-database-extra \
        libgeoip-dev \
        libmaxminddb-dev \
        libmaxminddb0 \
        mmdb-bin \
        iptables \
        ipset \
        conntrack-tools \
        net-tools \
        htop \
        iftop \
        nethogs \
        tcpdump \
        wireshark \
        snort \
        suricata \
        fail2ban \
        logwatch \
        rsyslog \
        systemd \
        systemd-sysv \
        cron \
        anacron \
        logrotate \
        supervisor \
        monit \
        nagios-plugins \
        zabbix-agent \
        prometheus \
        grafana \
        elasticsearch \
        logstash \
        kibana \
        filebeat \
        metricbeat \
        packetbeat \
        auditd \
        apparmor \
        apparmor-utils \
        selinux-basics \
        selinux-policy-default \
        ufw \
        shorewall \
        shorewall6 \
        arptables \
        ebtables \
        nftables \
        libnftnl-dev \
        libmnl-dev \
        libnetfilter-conntrack-dev \
        libnetfilter-queue-dev \
        libnfnetlink-dev \
        libnetfilter-log-dev \
        libnetfilter-acct-dev \
        libnetfilter-cttimeout-dev \
        libnetfilter-cthelper-dev \
        libnetfilter-queue-dev \
        libnetfilter-log-dev \
        libnetfilter-acct-dev \
        libnetfilter-cttimeout-dev \
        libnetfilter-cthelper-dev \
        libnetfilter-queue-dev \
        libnetfilter-log-dev \
        libnetfilter-acct-dev \
        libnetfilter-cttimeout-dev \
        libnetfilter-cthelper-dev
    
    print_success "Dependencies installed successfully"
}

# Function to setup hugepages
setup_hugepages() {
    print_status "Setting up hugepages..."
    
    # Create hugepages mount point
    mkdir -p /mnt/huge
    
    # Add to fstab
    if ! grep -q "huge" /etc/fstab; then
        echo "nodev /mnt/huge hugetlbfs defaults 0 0" >> /etc/fstab
    fi
    
    # Mount hugepages
    mount -t hugetlbfs nodev /mnt/huge
    
    # Set hugepages
    echo 1024 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
    
    print_success "Hugepages configured successfully"
}

# Function to setup network interfaces
setup_network() {
    print_status "Setting up network interfaces..."
    
    # Create network configuration
    cat > /etc/network/interfaces.d/gatekeeper-enhanced << EOF
# Gatekeeper Enhanced Network Configuration
auto lo
iface lo inet loopback

# Front Interface (External)
auto eth0
iface eth0 inet static
    address 10.0.1.1
    netmask 255.255.255.0
    gateway 10.0.1.254
    mtu 1500

# Back Interface (Internal)
auto eth1
iface eth1 inet static
    address 10.0.2.1
    netmask 255.255.255.0
    mtu 2048
EOF
    
    print_success "Network interfaces configured"
}

# Function to setup firewall rules
setup_firewall() {
    print_status "Setting up firewall rules..."
    
    # Reset iptables
    iptables -F
    iptables -X
    iptables -t nat -F
    iptables -t nat -X
    iptables -t mangle -F
    iptables -t mangle -X
    
    # Set default policies
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT ACCEPT
    
    # Allow loopback
    iptables -A INPUT -i lo -j ACCEPT
    
    # Allow established connections
    iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    
    # Allow SSH
    iptables -A INPUT -p tcp --dport 22 -j ACCEPT
    
    # Allow HTTP/HTTPS for web interface
    iptables -A INPUT -p tcp --dport 80 -j ACCEPT
    iptables -A INPUT -p tcp --dport 443 -j ACCEPT
    
    # Allow Gatekeeper ports
    iptables -A INPUT -p tcp --dport 5000 -j ACCEPT
    
    # Rate limiting
    iptables -A INPUT -p tcp --dport 80 -m limit --limit 100/minute --limit-burst 200 -j ACCEPT
    iptables -A INPUT -p tcp --dport 443 -m limit --limit 100/minute --limit-burst 200 -j ACCEPT
    
    # DDoS protection
    iptables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
    iptables -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
    iptables -A INPUT -p tcp --tcp-flags ALL FIN,PSH,URG -j DROP
    iptables -A INPUT -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -j DROP
    iptables -A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j DROP
    iptables -A INPUT -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
    
    # Save iptables rules
    iptables-save > /etc/iptables/rules.v4
    
    print_success "Firewall rules configured"
}

# Function to setup monitoring
setup_monitoring() {
    print_status "Setting up monitoring..."
    
    # Install monitoring tools
    apt-get install -y \
        prometheus \
        grafana \
        alertmanager \
        node-exporter \
        blackbox-exporter \
        cadvisor \
        elasticsearch \
        logstash \
        kibana \
        filebeat \
        metricbeat \
        packetbeat
    
    # Configure Prometheus
    cat > /etc/prometheus/prometheus.yml << EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'gatekeeper-enhanced'
    static_configs:
      - targets: ['localhost:9090']
  
  - job_name: 'node-exporter'
    static_configs:
      - targets: ['localhost:9100']
  
  - job_name: 'blackbox-exporter'
    static_configs:
      - targets: ['localhost:9115']
EOF
    
    # Configure Grafana
    systemctl enable grafana-server
    systemctl start grafana-server
    
    # Configure Elasticsearch
    systemctl enable elasticsearch
    systemctl start elasticsearch
    
    print_success "Monitoring configured"
}

# Function to setup logging
setup_logging() {
    print_status "Setting up logging..."
    
    # Create log directories
    mkdir -p $LOG_DIR
    mkdir -p /var/log/gatekeeper-enhanced/attacks
    mkdir -p /var/log/gatekeeper-enhanced/anomalies
    mkdir -p /var/log/gatekeeper-enhanced/geo
    mkdir -p /var/log/gatekeeper-enhanced/ml
    mkdir -p /var/log/gatekeeper-enhanced/behavior
    
    # Configure rsyslog
    cat > /etc/rsyslog.d/gatekeeper-enhanced.conf << EOF
# Gatekeeper Enhanced Logging
local0.*    $LOG_DIR/gatekeeper-enhanced.log
local1.*    $LOG_DIR/attacks.log
local2.*    $LOG_DIR/anomalies.log
local3.*    $LOG_DIR/geo.log
local4.*    $LOG_DIR/ml.log
local5.*    $LOG_DIR/behavior.log
EOF
    
    # Configure logrotate
    cat > /etc/logrotate.d/gatekeeper-enhanced << EOF
$LOG_DIR/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        systemctl reload rsyslog
    endscript
}
EOF
    
    # Restart rsyslog
    systemctl restart rsyslog
    
    print_success "Logging configured"
}

# Function to setup web interface
setup_web_interface() {
    print_status "Setting up web interface..."
    
    # Create web interface directory
    mkdir -p $WEB_INTERFACE_DIR
    
    # Install Python dependencies
    pip3 install flask flask-socketio psutil python-socketio python-engineio eventlet gevent gevent-websocket
    
    # Configure nginx
    cat > /etc/nginx/sites-available/gatekeeper-enhanced << EOF
server {
    listen 80;
    server_name localhost;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /socket.io {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/gatekeeper-enhanced /etc/nginx/sites-enabled/
    
    # Test nginx configuration
    nginx -t
    
    # Restart nginx
    systemctl restart nginx
    
    print_success "Web interface configured"
}

# Function to setup systemd services
setup_services() {
    print_status "Setting up systemd services..."
    
    # Create Gatekeeper Enhanced service
    cat > /etc/systemd/system/gatekeeper-enhanced.service << EOF
[Unit]
Description=Gatekeeper Enhanced Anti-DDoS Protection
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/gatekeeper-enhanced
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gatekeeper-enhanced

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$LOG_DIR $CONFIG_DIR

[Install]
WantedBy=multi-user.target
EOF
    
    # Create web interface service
    cat > /etc/systemd/system/gatekeeper-enhanced-web.service << EOF
[Unit]
Description=Gatekeeper Enhanced Web Interface
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$WEB_INTERFACE_DIR
ExecStart=/usr/bin/python3 $WEB_INTERFACE_DIR/app.py
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gatekeeper-enhanced-web

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$LOG_DIR $CONFIG_DIR

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd
    systemctl daemon-reload
    
    # Enable services
    systemctl enable gatekeeper-enhanced
    systemctl enable gatekeeper-enhanced-web
    
    print_success "Systemd services configured"
}

# Function to setup configuration
setup_configuration() {
    print_status "Setting up configuration..."
    
    # Create configuration directory
    mkdir -p $CONFIG_DIR
    
    # Create main configuration file
    cat > $CONFIG_DIR/gatekeeper-enhanced.conf << EOF
# Gatekeeper Enhanced Configuration
[general]
version = $ENHANCED_VERSION
log_level = INFO
log_file = $LOG_DIR/gatekeeper-enhanced.log

[network]
front_interface = eth0
back_interface = eth1
front_ip = 10.0.1.1/24
back_ip = 10.0.2.1/24
mtu = 1500

[security]
enable_syn_flood_detection = true
enable_udp_flood_detection = true
enable_icmp_flood_detection = true
enable_http_flood_detection = true
enable_dns_amplification_detection = true
enable_ntp_amplification_detection = true

[rate_limiting]
default_rate_limit = 1000
burst_limit = 100
connection_limit = 1000

[machine_learning]
enable_ml_detection = true
ml_model = RANDOM_FOREST
ml_confidence_threshold = 0.8
ml_window_size = 1000
ml_update_interval = 60

[behavioral_analysis]
enable_behavioral_analysis = true
behavior_window_size = 300
behavior_sample_size = 1000
anomaly_threshold = 2.5

[geographic_protection]
enable_geo_protection = true
geo_db_path = /usr/share/GeoIP/GeoIP.dat
geo_cache_size = 10000

[protocol_analysis]
enable_protocol_analysis = true
enable_custom_protocols = true

[performance]
max_flows = 100000
flow_timeout = 300
cleanup_interval = 60

[custom_rules]
enable_custom_rules = true
max_custom_rules = 1000
custom_rules_file = $CONFIG_DIR/custom_rules.conf

[monitoring]
enable_monitoring = true
prometheus_port = 9090
grafana_port = 3000
elasticsearch_port = 9200
kibana_port = 5601

[web_interface]
enable_web_interface = true
web_port = 5000
web_host = 0.0.0.0
EOF
    
    # Create custom rules file
    cat > $CONFIG_DIR/custom_rules.conf << EOF
# Custom Rules Configuration
# Format: rule_id|rule_name|condition|action|priority

# Example rules
1|block_known_botnet|src_ip in botnet_list|DROP|HIGH
2|allow_whitelist|src_ip in whitelist|ACCEPT|HIGH
3|rate_limit_aggressive|packets_per_sec > 1000|RATE_LIMIT|MEDIUM
4|geo_block_suspicious|country_code in blocked_countries|DROP|MEDIUM
EOF
    
    print_success "Configuration files created"
}

# Function to setup cron jobs
setup_cron() {
    print_status "Setting up cron jobs..."
    
    # Create cron jobs
    cat > /etc/cron.d/gatekeeper-enhanced << EOF
# Gatekeeper Enhanced Cron Jobs

# Cleanup old logs (daily at 2 AM)
0 2 * * * root find $LOG_DIR -name "*.log.*" -mtime +30 -delete

# Update GeoIP database (weekly on Sunday at 3 AM)
0 3 * * 0 root /usr/bin/geoipupdate

# Backup configuration (daily at 4 AM)
0 4 * * * root tar -czf /backup/gatekeeper-enhanced-\$(date +\%Y\%m\%d).tar.gz $CONFIG_DIR $LOG_DIR

# Generate reports (daily at 5 AM)
0 5 * * * root $INSTALL_DIR/scripts/generate_reports.sh

# Update threat intelligence (hourly)
0 * * * * root $INSTALL_DIR/scripts/update_threat_intel.sh

# Health check (every 5 minutes)
*/5 * * * * root $INSTALL_DIR/scripts/health_check.sh
EOF
    
    print_success "Cron jobs configured"
}

# Function to setup scripts
setup_scripts() {
    print_status "Setting up scripts..."
    
    # Create scripts directory
    mkdir -p $INSTALL_DIR/scripts
    
    # Create health check script
    cat > $INSTALL_DIR/scripts/health_check.sh << 'EOF'
#!/bin/bash

# Gatekeeper Enhanced Health Check Script

LOG_FILE="/var/log/gatekeeper-enhanced/health_check.log"
SERVICE_NAME="gatekeeper-enhanced"

# Check if service is running
if ! systemctl is-active --quiet $SERVICE_NAME; then
    echo "$(date): $SERVICE_NAME is not running. Attempting to restart..." >> $LOG_FILE
    systemctl restart $SERVICE_NAME
fi

# Check memory usage
MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.2f", $3/$2 * 100.0}')
if (( $(echo "$MEMORY_USAGE > 90" | bc -l) )); then
    echo "$(date): High memory usage: ${MEMORY_USAGE}%" >> $LOG_FILE
fi

# Check disk usage
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 90 ]; then
    echo "$(date): High disk usage: ${DISK_USAGE}%" >> $LOG_FILE
fi

# Check log file size
LOG_SIZE=$(du -m /var/log/gatekeeper-enhanced/ | awk '{sum+=$1} END {print sum}')
if [ $LOG_SIZE -gt 1000 ]; then
    echo "$(date): Large log files detected: ${LOG_SIZE}MB" >> $LOG_FILE
fi
EOF
    
    # Create report generation script
    cat > $INSTALL_DIR/scripts/generate_reports.sh << 'EOF'
#!/bin/bash

# Gatekeeper Enhanced Report Generation Script

REPORT_DIR="/var/log/gatekeeper-enhanced/reports"
DATE=$(date +%Y%m%d)

mkdir -p $REPORT_DIR

# Generate daily attack report
echo "=== Gatekeeper Enhanced Daily Report - $DATE ===" > $REPORT_DIR/daily_report_$DATE.txt
echo "Attack Statistics:" >> $REPORT_DIR/daily_report_$DATE.txt
grep "ATTACK_DETECTED" /var/log/gatekeeper-enhanced/attacks.log | wc -l >> $REPORT_DIR/daily_report_$DATE.txt

# Generate anomaly report
echo "Anomaly Statistics:" >> $REPORT_DIR/daily_report_$DATE.txt
grep "ANOMALY_DETECTED" /var/log/gatekeeper-enhanced/anomalies.log | wc -l >> $REPORT_DIR/daily_report_$DATE.txt

# Generate performance report
echo "Performance Statistics:" >> $REPORT_DIR/daily_report_$DATE.txt
echo "CPU Usage: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)%" >> $REPORT_DIR/daily_report_$DATE.txt
echo "Memory Usage: $(free | grep Mem | awk '{printf "%.2f", $3/$2 * 100.0}')%" >> $REPORT_DIR/daily_report_$DATE.txt
EOF
    
    # Create threat intelligence update script
    cat > $INSTALL_DIR/scripts/update_threat_intel.sh << 'EOF'
#!/bin/bash

# Gatekeeper Enhanced Threat Intelligence Update Script

THREAT_DIR="/var/lib/gatekeeper-enhanced/threat_intel"
mkdir -p $THREAT_DIR

# Update botnet IP lists
curl -s "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset" > $THREAT_DIR/botnet_ips.txt

# Update malicious domain lists
curl -s "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts" > $THREAT_DIR/malicious_domains.txt

# Update spam IP lists
curl -s "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/spamhaus_drop.netset" > $THREAT_DIR/spam_ips.txt

echo "$(date): Threat intelligence updated" >> /var/log/gatekeeper-enhanced/threat_intel.log
EOF
    
    # Make scripts executable
    chmod +x $INSTALL_DIR/scripts/*.sh
    
    print_success "Scripts configured"
}

# Function to finalize setup
finalize_setup() {
    print_status "Finalizing setup..."
    
    # Set proper permissions
    chown -R root:root $INSTALL_DIR
    chmod -R 755 $INSTALL_DIR
    chown -R root:root $CONFIG_DIR
    chmod -R 644 $CONFIG_DIR
    chown -R root:root $LOG_DIR
    chmod -R 755 $LOG_DIR
    
    # Create backup directory
    mkdir -p /backup
    chmod 700 /backup
    
    # Create systemd timer for automatic updates
    cat > /etc/systemd/system/gatekeeper-enhanced-update.timer << EOF
[Unit]
Description=Run Gatekeeper Enhanced updates
Requires=gatekeeper-enhanced-update.service

[Timer]
OnCalendar=weekly
Persistent=true

[Install]
WantedBy=timers.target
EOF
    
    cat > /etc/systemd/system/gatekeeper-enhanced-update.service << EOF
[Unit]
Description=Gatekeeper Enhanced Update Service
Type=oneshot
ExecStart=$INSTALL_DIR/scripts/update_threat_intel.sh

[Install]
WantedBy=multi-user.target
EOF
    
    # Enable timer
    systemctl enable gatekeeper-enhanced-update.timer
    systemctl start gatekeeper-enhanced-update.timer
    
    print_success "Setup finalized"
}

# Function to display completion message
display_completion() {
    echo
    print_success "Enhanced Gatekeeper Anti-DDoS Protection System Setup Complete!"
    echo
    echo "Installation Summary:"
    echo "===================="
    echo "Version: $ENHANCED_VERSION"
    echo "Install Directory: $INSTALL_DIR"
    echo "Config Directory: $CONFIG_DIR"
    echo "Log Directory: $LOG_DIR"
    echo "Web Interface: http://localhost:5000"
    echo
    echo "Services:"
    echo "========="
    echo "- gatekeeper-enhanced: Main protection service"
    echo "- gatekeeper-enhanced-web: Web interface"
    echo "- prometheus: Metrics collection"
    echo "- grafana: Monitoring dashboard"
    echo "- elasticsearch: Log storage"
    echo "- kibana: Log visualization"
    echo
    echo "Next Steps:"
    echo "==========="
    echo "1. Start the services: systemctl start gatekeeper-enhanced"
    echo "2. Access web interface: http://localhost:5000"
    echo "3. Configure monitoring: http://localhost:3000 (Grafana)"
    echo "4. View logs: http://localhost:5601 (Kibana)"
    echo "5. Check status: systemctl status gatekeeper-enhanced"
    echo
    echo "Documentation:"
    echo "=============="
    echo "- Configuration: $CONFIG_DIR/gatekeeper-enhanced.conf"
    echo "- Logs: $LOG_DIR/"
    echo "- Scripts: $INSTALL_DIR/scripts/"
    echo
    print_success "Setup completed successfully!"
}

# Main installation function
main() {
    echo "Enhanced Gatekeeper Anti-DDoS Protection System Setup"
    echo "=================================================="
    echo "Version: $ENHANCED_VERSION"
    echo
    
    # Check if running as root
    check_root
    
    # Check system requirements
    check_requirements
    
    # Install dependencies
    install_dependencies
    
    # Setup system components
    setup_hugepages
    setup_network
    setup_firewall
    setup_monitoring
    setup_logging
    setup_web_interface
    setup_services
    setup_configuration
    setup_cron
    setup_scripts
    
    # Finalize setup
    finalize_setup
    
    # Display completion message
    display_completion
}

# Run main function
main "$@" 