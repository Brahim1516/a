# Enhanced Gatekeeper Anti-DDoS Protection System

## Overview

The Enhanced Gatekeeper Anti-DDoS Protection System is a comprehensive, enterprise-grade DDoS protection solution that extends the original Gatekeeper with advanced features including machine learning, behavioral analysis, geographic protection, and real-time monitoring.

## Key Features

### 🛡️ **Advanced Attack Detection**
- **SYN Flood Detection**: Real-time detection of TCP SYN flood attacks
- **UDP Flood Protection**: Protection against UDP amplification attacks
- **ICMP Flood Detection**: Detection of ICMP-based attacks
- **HTTP Flood Protection**: Protection against HTTP-based attacks
- **DNS Amplification**: Detection of DNS amplification attacks
- **NTP Amplification**: Protection against NTP amplification attacks
- **Custom Attack Patterns**: Support for custom attack signatures

### 🤖 **Machine Learning Integration**
- **Anomaly Detection**: ML-based anomaly detection using multiple algorithms
- **Behavioral Analysis**: Real-time behavioral pattern analysis
- **Predictive Protection**: Proactive threat detection
- **Model Training**: Continuous model improvement
- **Confidence Scoring**: ML confidence-based decision making

### 🌍 **Geographic Protection**
- **GeoIP Blocking**: Country and region-based blocking
- **Whitelist/Blacklist**: Geographic access control
- **Real-time Updates**: Dynamic geographic rule updates
- **Custom Regions**: Support for custom geographic zones

### 📊 **Real-time Monitoring**
- **Live Metrics**: Real-time performance metrics
- **Attack Visualization**: Visual attack pattern analysis
- **System Health**: Comprehensive system monitoring
- **Alert System**: Real-time alerting and notifications

### ⚙️ **Advanced Configuration**
- **Custom Rules**: Flexible custom rule engine
- **Protocol Analysis**: Deep packet inspection
- **Rate Limiting**: Advanced rate limiting capabilities
- **Performance Tuning**: Optimized for high-performance environments

## Architecture

### Core Components

1. **Enhanced Flow Engine**: Advanced packet processing and flow management
2. **ML Engine**: Machine learning-based threat detection
3. **Behavioral Analyzer**: Real-time behavioral pattern analysis
4. **Geographic Engine**: Geographic-based protection
5. **Web Interface**: Real-time monitoring and management
6. **Monitoring Stack**: Prometheus, Grafana, Elasticsearch, Kibana

### Data Flow

```
Network Traffic → Enhanced Flow Engine → Attack Detection → ML Analysis → Behavioral Analysis → Geographic Check → Custom Rules → Action (Allow/Block/Rate Limit)
```

## Installation

### Prerequisites

- Ubuntu 20.04 LTS or higher
- Kernel 4.18 or higher
- 4GB RAM minimum (8GB recommended)
- 2 CPU cores minimum (4+ recommended)
- 50GB free disk space

### Quick Installation

```bash
# Clone the repository
git clone https://github.com/your-repo/gatekeeper-enhanced.git
cd gatekeeper-enhanced

# Run the setup script
sudo ./setup_enhanced.sh
```

### Manual Installation

1. **Install Dependencies**
```bash
sudo apt-get update
sudo apt-get install -y build-essential cmake git libpcap-dev libssl-dev
```

2. **Setup Hugepages**
```bash
echo 1024 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
mkdir -p /mnt/huge
mount -t hugetlbfs nodev /mnt/huge
```

3. **Compile and Install**
```bash
make clean && make
sudo make install
```

4. **Configure Services**
```bash
sudo systemctl enable gatekeeper-enhanced
sudo systemctl start gatekeeper-enhanced
```

## Configuration

### Main Configuration File

Edit `/etc/gatekeeper-enhanced/gatekeeper-enhanced.conf`:

```ini
[general]
version = 2.0.0
log_level = INFO
log_file = /var/log/gatekeeper-enhanced/gatekeeper-enhanced.log

[network]
front_interface = eth0
back_interface = eth1
front_ip = 10.0.1.1/24
back_ip = 10.0.2.1/24
mtu = 1500

[security]
enable_syn_flood_detection = true
enable_udp_flood_detection = true
enable_icmp_flood_detection = true
enable_http_flood_detection = true
enable_dns_amplification_detection = true
enable_ntp_amplification_detection = true

[rate_limiting]
default_rate_limit = 1000
burst_limit = 100
connection_limit = 1000

[machine_learning]
enable_ml_detection = true
ml_model = RANDOM_FOREST
ml_confidence_threshold = 0.8
ml_window_size = 1000
ml_update_interval = 60

[behavioral_analysis]
enable_behavioral_analysis = true
behavior_window_size = 300
behavior_sample_size = 1000
anomaly_threshold = 2.5

[geographic_protection]
enable_geo_protection = true
geo_db_path = /usr/share/GeoIP/GeoIP.dat
geo_cache_size = 10000

[protocol_analysis]
enable_protocol_analysis = true
enable_custom_protocols = true

[performance]
max_flows = 100000
flow_timeout = 300
cleanup_interval = 60

[custom_rules]
enable_custom_rules = true
max_custom_rules = 1000
custom_rules_file = /etc/gatekeeper-enhanced/custom_rules.conf

[monitoring]
enable_monitoring = true
prometheus_port = 9090
grafana_port = 3000
elasticsearch_port = 9200
kibana_port = 5601

[web_interface]
enable_web_interface = true
web_port = 5000
web_host = 0.0.0.0
```

### Custom Rules Configuration

Edit `/etc/gatekeeper-enhanced/custom_rules.conf`:

```ini
# Custom Rules Configuration
# Format: rule_id|rule_name|condition|action|priority

# Block known botnet IPs
1|block_known_botnet|src_ip in botnet_list|DROP|HIGH

# Allow whitelisted IPs
2|allow_whitelist|src_ip in whitelist|ACCEPT|HIGH

# Rate limit aggressive traffic
3|rate_limit_aggressive|packets_per_sec > 1000|RATE_LIMIT|MEDIUM

# Block suspicious geographic regions
4|geo_block_suspicious|country_code in blocked_countries|DROP|MEDIUM

# Block specific protocols
5|block_telnet|protocol == 23|DROP|HIGH

# Block large packets
6|block_large_packets|packet_size > 1500|DROP|MEDIUM
```

## Usage

### Starting the System

```bash
# Start the main service
sudo systemctl start gatekeeper-enhanced

# Start the web interface
sudo systemctl start gatekeeper-enhanced-web

# Check status
sudo systemctl status gatekeeper-enhanced
```

### Web Interface

Access the web interface at `http://localhost:5000`:

- **Dashboard**: Real-time system overview
- **Metrics**: Detailed performance metrics
- **Configuration**: System configuration management
- **Logs**: Real-time log viewing and analysis

### Command Line Tools

```bash
# Check system status
gatekeeper-enhanced status

# View statistics
gatekeeper-enhanced stats

# Block IP address
gatekeeper-enhanced block-ip 192.168.1.100

# Unblock IP address
gatekeeper-enhanced unblock-ip 192.168.1.100

# View logs
gatekeeper-enhanced logs

# Update configuration
gatekeeper-enhanced reload-config
```

## Monitoring

### Prometheus Metrics

The system exposes metrics on port 9090:

- `gatekeeper_attacks_total`: Total attack detections
- `gatekeeper_packets_processed`: Packets processed
- `gatekeeper_packets_dropped`: Packets dropped
- `gatekeeper_ml_predictions`: ML predictions made
- `gatekeeper_behavioral_anomalies`: Behavioral anomalies detected

### Grafana Dashboards

Access Grafana at `http://localhost:3000`:

- **System Overview**: General system metrics
- **Attack Analysis**: Attack detection and analysis
- **Performance Metrics**: System performance monitoring
- **ML Insights**: Machine learning model performance

### Elasticsearch/Kibana

Access Kibana at `http://localhost:5601`:

- **Log Analysis**: Advanced log search and analysis
- **Attack Patterns**: Visual attack pattern analysis
- **Geographic Analysis**: Geographic attack distribution
- **Real-time Monitoring**: Live log streaming

## Advanced Features

### Machine Learning

The system supports multiple ML models:

- **Random Forest**: Ensemble learning for attack detection
- **SVM**: Support Vector Machine for anomaly detection
- **Neural Network**: Deep learning for complex patterns
- **Isolation Forest**: Unsupervised anomaly detection
- **LOF**: Local Outlier Factor for anomaly detection

### Behavioral Analysis

Real-time behavioral pattern analysis:

- **Normal Behavior**: Baseline behavior establishment
- **Aggressive Behavior**: Detection of aggressive patterns
- **Scanning Behavior**: Port and service scanning detection
- **Botnet Behavior**: Botnet communication patterns
- **Malware Behavior**: Malware communication patterns

### Geographic Protection

Advanced geographic-based protection:

- **Country Blocking**: Block traffic from specific countries
- **Region Blocking**: Block traffic from specific regions
- **Whitelist**: Allow traffic from trusted regions
- **Dynamic Updates**: Real-time geographic rule updates

### Custom Protocols

Support for custom protocol analysis:

- **Protocol Detection**: Automatic protocol identification
- **Custom Rules**: Protocol-specific rules
- **Deep Inspection**: Deep packet inspection
- **Signature Matching**: Custom signature matching

## Performance Tuning

### System Optimization

```bash
# Increase file descriptors
echo "* soft nofile 65536" >> /etc/security/limits.conf
echo "* hard nofile 65536" >> /etc/security/limits.conf

# Optimize network settings
echo "net.core.rmem_max = 16777216" >> /etc/sysctl.conf
echo "net.core.wmem_max = 16777216" >> /etc/sysctl.conf
echo "net.ipv4.tcp_rmem = 4096 87380 16777216" >> /etc/sysctl.conf
echo "net.ipv4.tcp_wmem = 4096 65536 16777216" >> /etc/sysctl.conf

# Apply changes
sysctl -p
```

### Memory Optimization

```bash
# Configure hugepages
echo 2048 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages

# Optimize memory allocation
echo "vm.nr_hugepages = 2048" >> /etc/sysctl.conf
```

### CPU Optimization

```bash
# Set CPU governor to performance
echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

# Pin processes to specific cores
taskset -cp 0-3 $(pgrep gatekeeper-enhanced)
```

## Troubleshooting

### Common Issues

1. **Service Won't Start**
```bash
# Check logs
journalctl -u gatekeeper-enhanced -f

# Check configuration
gatekeeper-enhanced validate-config

# Check dependencies
ldd /usr/bin/gatekeeper-enhanced
```

2. **High CPU Usage**
```bash
# Check process usage
top -p $(pgrep gatekeeper-enhanced)

# Check configuration
grep -i "cpu" /etc/gatekeeper-enhanced/gatekeeper-enhanced.conf

# Optimize settings
gatekeeper-enhanced optimize-performance
```

3. **Memory Issues**
```bash
# Check memory usage
free -h

# Check hugepages
cat /proc/meminfo | grep Huge

# Restart with more memory
systemctl restart gatekeeper-enhanced
```

4. **Network Issues**
```bash
# Check interface status
ip link show

# Check routing
ip route show

# Check firewall
iptables -L -n -v
```

### Debug Mode

Enable debug mode for troubleshooting:

```bash
# Edit configuration
sed -i 's/log_level = INFO/log_level = DEBUG/' /etc/gatekeeper-enhanced/gatekeeper-enhanced.conf

# Restart service
systemctl restart gatekeeper-enhanced

# Monitor debug logs
tail -f /var/log/gatekeeper-enhanced/gatekeeper-enhanced.log
```

## Security Considerations

### Network Security

1. **Firewall Configuration**
```bash
# Configure iptables
iptables -A INPUT -p tcp --dport 5000 -j ACCEPT
iptables -A INPUT -p tcp --dport 9090 -j ACCEPT
iptables -A INPUT -p tcp --dport 3000 -j ACCEPT
iptables -A INPUT -p tcp --dport 5601 -j ACCEPT
```

2. **Access Control**
```bash
# Restrict web interface access
sed -i 's/web_host = 0.0.0.0/web_host = 127.0.0.1/' /etc/gatekeeper-enhanced/gatekeeper-enhanced.conf
```

### System Security

1. **File Permissions**
```bash
# Secure configuration files
chmod 600 /etc/gatekeeper-enhanced/gatekeeper-enhanced.conf
chmod 600 /etc/gatekeeper-enhanced/custom_rules.conf
```

2. **Service Security**
```bash
# Run as non-root user
useradd -r -s /bin/false gatekeeper
chown gatekeeper:gatekeeper /var/log/gatekeeper-enhanced/
```

## API Reference

### REST API Endpoints

```bash
# Get system status
curl http://localhost:5000/api/status

# Get metrics
curl http://localhost:5000/api/metrics

# Block IP
curl -X POST http://localhost:5000/api/block_ip \
  -H "Content-Type: application/json" \
  -d '{"ip_address": "192.168.1.100", "duration": 3600}'

# Unblock IP
curl -X POST http://localhost:5000/api/unblock_ip \
  -H "Content-Type: application/json" \
  -d '{"ip_address": "192.168.1.100"}'

# Get logs
curl http://localhost:5000/api/get_logs?lines=100
```

### WebSocket Events

```javascript
// Connect to WebSocket
const socket = io('http://localhost:5000');

// Listen for metrics updates
socket.on('metrics_update', function(data) {
    console.log('Metrics updated:', data);
});

// Listen for attack alerts
socket.on('attack_detected', function(data) {
    console.log('Attack detected:', data);
});
```

## Development

### Building from Source

```bash
# Clone repository
git clone https://github.com/your-repo/gatekeeper-enhanced.git
cd gatekeeper-enhanced

# Install build dependencies
sudo apt-get install -y build-essential cmake git libpcap-dev libssl-dev

# Build
mkdir build && cd build
cmake ..
make -j$(nproc)

# Install
sudo make install
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

### Testing

```bash
# Run unit tests
make test

# Run integration tests
make integration-test

# Run performance tests
make performance-test
```

## Support

### Documentation

- **User Guide**: Complete usage instructions
- **API Reference**: Detailed API documentation
- **Configuration Guide**: Configuration options
- **Troubleshooting Guide**: Common issues and solutions

### Community

- **GitHub Issues**: Bug reports and feature requests
- **Discussions**: Community discussions
- **Wiki**: Community-maintained documentation

### Professional Support

- **Enterprise Support**: Professional support services
- **Consulting**: Implementation and optimization services
- **Training**: Custom training programs

## License

This project is licensed under the GNU General Public License v3.0. See the LICENSE file for details.

## Acknowledgments

- Original Gatekeeper project contributors
- Open source community contributors
- Security researchers and practitioners
- Machine learning and networking experts

---

**Note**: This enhanced system builds upon the original Gatekeeper DDoS protection system and adds enterprise-grade features for comprehensive network protection. 